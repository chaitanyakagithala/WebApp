package com.example.demo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	@RequestMapping("home")
	public String show(@RequestParam("name") String myname,HttpSession session) {
		
		System.out.println("hi"+ myname);
		session.setAttribute("name",myname);
		return "home.jsp";
	}

}
